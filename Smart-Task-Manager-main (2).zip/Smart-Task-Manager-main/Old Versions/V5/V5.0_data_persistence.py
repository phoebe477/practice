# feature/data-persistence-improvement
# Version 5.0 - Robust Data Manager with Validation + Safer Backups

import json
import os
from datetime import datetime
from pathlib import Path
import shutil


class DataManager:
    """
    Handles all data persistence, backups, and recovery.

    Features:
    - Safe load/save with validation
    - Automatic timestamped backups
    - Backup cleanup (limit stored files)
    - Recovery from corrupted files
    - Import/export support
    """

    def __init__(self, data_file="student_tasks.json", backup_dir="backups"):
        self.data_file = Path(data_file)
        self.backup_dir = Path(backup_dir)
        self.ensure_backup_dir()

    # ====================== SETUP ======================

    def ensure_backup_dir(self):
        """Ensure backup directory exists."""
        self.backup_dir.mkdir(exist_ok=True)

    # ====================== VALIDATION ======================

    def validate_data_structure(self, data):
        """
        Validate structure of loaded JSON data.

        Returns:
            bool: True if valid, False otherwise
        """
        if not isinstance(data, dict):
            return False

        if "tasks" not in data or "subjects" not in data:
            return False

        if not isinstance(data["tasks"], list):
            return False

        return True

    # ====================== LOAD ======================

    def load_data(self):
        """
        Load data safely with fallback to backup.

        Returns:
            tuple: (tasks, subjects)
        """
        try:
            if self.data_file.exists():
                with open(self.data_file, "r", encoding="utf-8") as f:
                    data = json.load(f)

                if self.validate_data_structure(data):
                    return data["tasks"], data["subjects"]
                else:
                    print("Invalid data structure. Attempting recovery...")

        except json.JSONDecodeError:
            print("Corrupted JSON detected. Attempting backup recovery...")

        except Exception as e:
            print(f"Unexpected load error: {e}")

        # fallback
        return self.load_from_latest_backup()

    # ====================== SAVE ======================

    def save_data(self, tasks, subjects):
        """
        Save data with backup protection.

        Returns:
            tuple: (success: bool, message: str)
        """
        try:
            # Create backup before overwrite
            self.create_backup()

            data = {
                "tasks": tasks,
                "subjects": subjects
            }

            # Write safely using temp file
            temp_file = self.data_file.with_suffix(".tmp")

            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)

            # Replace original file
            temp_file.replace(self.data_file)

            return True, "Data saved successfully"

        except Exception as e:
            return False, f"Save failed: {e}"

    # ====================== BACKUPS ======================

    def create_backup(self):
        """Create a timestamped backup."""
        try:
            if self.data_file.exists():
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_file = self.backup_dir / f"backup_{timestamp}.json"

                shutil.copy(self.data_file, backup_file)

                self.cleanup_old_backups(max_backups=10)
                return True

        except Exception as e:
            print(f"Backup failed: {e}")

        return False

    def cleanup_old_backups(self, max_backups=10):
        """Keep only the most recent backups."""
        try:
            backups = sorted(self.backup_dir.glob("backup_*.json"), reverse=True)

            for old_backup in backups[max_backups:]:
                old_backup.unlink()

        except Exception as e:
            print(f"Cleanup error: {e}")

    def load_from_latest_backup(self):
        """
        Recover data from latest backup.

        Returns:
            tuple: (tasks, subjects)
        """
        try:
            backups = sorted(self.backup_dir.glob("backup_*.json"), reverse=True)

            if backups:
                with open(backups[0], "r", encoding="utf-8") as f:
                    data = json.load(f)

                if self.validate_data_structure(data):
                    print("Recovered from backup.")
                    return data["tasks"], data["subjects"]

        except Exception as e:
            print(f"Recovery failed: {e}")

        return [], ["General"]

    # ====================== UTILITIES ======================

    def list_backups(self):
        """Return list of backup file paths."""
        try:
            return [str(b) for b in sorted(self.backup_dir.glob("backup_*.json"), reverse=True)]
        except:
            return []

    def restore_from_backup(self, backup_file):
        """Restore data from a chosen backup."""
        try:
            with open(backup_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            if self.validate_data_structure(data):
                return data["tasks"], data["subjects"]

        except Exception as e:
            print(f"Restore failed: {e}")

        return [], ["General"]

    def export_data(self, export_file):
        """Export current data file."""
        try:
            shutil.copy(self.data_file, export_file)
            return True, f"Exported to {export_file}"
        except Exception as e:
            return False, f"Export failed: {e}"

    def import_data(self, import_file):
        """
        Import external data file.

        Returns:
            tuple: (tasks, subjects) OR (None, error_message)
        """
        try:
            with open(import_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            if self.validate_data_structure(data):
                return data["tasks"], data["subjects"]

            return None, "Invalid file structure"

        except Exception as e:
            return None, f"Import failed: {e}"


# ====================== TEST ======================

if __name__ == "__main__":
    dm = DataManager()

    tasks, subjects = dm.load_data()
    print(f"Loaded {len(tasks)} tasks")

    success, msg = dm.save_data(tasks, subjects)
    print(msg)

    print(f"Backups available: {len(dm.list_backups())}")