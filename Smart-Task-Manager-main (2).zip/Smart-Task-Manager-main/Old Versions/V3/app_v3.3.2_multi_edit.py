# feature/multi-edit-improvement
# Version 3.4 - Improved Multi-Edit with Validation + Persistence

import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
from datetime import datetime


class TaskEditForm:
    """
    GUI form for editing single or multiple tasks.

    Features:
    - Single edit (title, subject, priority, due date)
    - Multi-edit (subject + priority only)
    - Input validation (title + UK datetime format)
    """

    def __init__(self, parent, tasks_to_edit=None):
        self.parent = parent
        self.tasks_to_edit = tasks_to_edit or []
        self.is_multi_edit = len(self.tasks_to_edit) > 1
        self.result = None
        self.dialog = None

    def validate_input(self, title, due_date):
        """Validate task input fields."""

        # Title validation (only for single edit)
        if not self.is_multi_edit and not title.strip():
            messagebox.showerror("Validation Error", "Task title cannot be empty!")
            return False

        # Date validation
        if due_date:
            try:
                datetime.strptime(due_date, "%d/%m/%Y %H:%M")
            except ValueError:
                messagebox.showerror(
                    "Validation Error",
                    "Invalid date format.\nUse DD/MM/YYYY HH:MM"
                )
                return False

        return True

    def show_form(self):
        """Display the form window."""

        self.dialog = tk.Toplevel(self.parent)
        dialog = self.dialog

        dialog.title("Multi-Edit Tasks" if self.is_multi_edit else "Edit Task")
        dialog.geometry("500x550")
        dialog.grab_set()

        # Variables
        title_v = tk.StringVar()
        subject_v = tk.StringVar(value=self.parent.subjects[0])
        priority_v = tk.StringVar(value="Medium")
        due_v = tk.StringVar()

        # Layout
        frame = tk.Frame(dialog, padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)

        if self.is_multi_edit:
            tk.Label(frame, text=f"Editing {len(self.tasks_to_edit)} Tasks",
                     font=("Segoe UI", 13, "bold")).pack(pady=10)

            tk.Label(frame,
                     text="Titles and dates cannot be edited in bulk mode",
                     fg="gray").pack()

        else:
            tk.Label(frame, text="Task Title").pack(anchor="w")
            tk.Entry(frame, textvariable=title_v).pack(fill=tk.X, pady=5)

        tk.Label(frame, text="Subject").pack(anchor="w", pady=(15, 0))
        ttk.Combobox(frame, textvariable=subject_v,
                     values=self.parent.subjects).pack(fill=tk.X, pady=5)

        tk.Label(frame, text="Priority").pack(anchor="w", pady=(15, 0))
        ttk.Combobox(frame, textvariable=priority_v,
                     values=["High", "Medium", "Low"]).pack(fill=tk.X, pady=5)

        if not self.is_multi_edit:
            tk.Label(frame, text="Due Date (DD/MM/YYYY HH:MM)").pack(anchor="w", pady=(15, 0))
            tk.Entry(frame, textvariable=due_v).pack(fill=tk.X, pady=5)

        # Save logic
        def save():
            if self.validate_input(title_v.get(), due_v.get()):

                # Add subject if new
                if subject_v.get() not in self.parent.subjects:
                    self.parent.subjects.append(subject_v.get())

                self.result = {
                    "title": title_v.get(),
                    "subject": subject_v.get(),
                    "priority": priority_v.get(),
                    "due": due_v.get()
                }

                dialog.destroy()

        # Buttons
        btn_frame = tk.Frame(frame)
        btn_frame.pack(pady=20)

        tk.Button(btn_frame, text="Save", bg="#6366F1", fg="white",
                  command=save, padx=20).pack(side=tk.LEFT, padx=5)

        tk.Button(btn_frame, text="Cancel",
                  command=dialog.destroy, padx=20).pack(side=tk.LEFT, padx=5)


class StudentTaskTracker:
    """
    Handles task data and multi-edit operations.

    Responsibilities:
    - Load/save task data (JSON persistence)
    - Manage subject list
    - Apply multi-edit updates
    """

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Student Task Tracker")

        self.tasks = []
        self.subjects = ["General"]
        self.data_file = "student_tasks.json"

        self.load_data()

    def load_data(self):
        """Load tasks from JSON file."""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.tasks = data.get("tasks", [])
                    self.subjects = data.get("subjects", ["General"])
            except:
                pass

    def save_data(self):
        """Save tasks to JSON file."""
        with open(self.data_file, "w", encoding="utf-8") as f:
            json.dump({
                "tasks": self.tasks,
                "subjects": self.subjects
            }, f, indent=4)

    def edit_multiple_tasks(self, task_ids):
        """
        Open multi-edit form and apply changes.

        Args:
            task_ids (list[int]): IDs of tasks to edit
        """

        selected_tasks = [t for t in self.tasks if t["id"] in task_ids]

        form = TaskEditForm(self.root, selected_tasks)
        form.show_form()
        self.root.wait_window(form.dialog)

        if form.result:
            for task in self.tasks:
                if task["id"] in task_ids:
                    task["subject"] = form.result["subject"]
                    task["priority"] = form.result["priority"]

                    # Only update title/due if single edit
                    if len(task_ids) == 1:
                        task["title"] = form.result["title"]
                        task["due"] = form.result["due"]

            self.save_data()


if __name__ == "__main__":
    app = StudentTaskTracker()
    app.root.mainloop()
