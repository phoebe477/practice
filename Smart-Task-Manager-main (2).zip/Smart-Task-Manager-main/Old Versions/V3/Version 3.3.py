#Version 3.3
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime
import json
import os

class StudentTaskTracker:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Student Task Tracker")
        self.root.geometry("1320x780")
        self.root.minsize(1100, 680)

        # Data
        self.tasks = []
        self.subjects = ["General"]
        self.data_file = "student_tasks.json"
        self.dark_mode = False

        self.load_data()
        self.create_modern_gui()
        self.populate_task_list()

        # Auto-refresh countdown every 60 seconds
        self.root.after(60000, self.refresh_countdowns)

    # ====================== LOAD / SAVE ======================
    def load_data(self):
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.tasks = data.get("tasks", [])
                    self.subjects = data.get("subjects", ["General"])
            except:
                pass

    def save_data(self):
        try:
            with open(self.data_file, "w", encoding="utf-8") as f:
                json.dump({"tasks": self.tasks, "subjects": self.subjects}, f, indent=4)
        except Exception as e:
            messagebox.showerror("Save Error", f"Could not save data:\n{e}")

    # ====================== GUI ======================
    def create_modern_gui(self):
        # Setup ttk Style for Dark Mode
        self.style = ttk.Style()
        
        self.main_container = tk.Frame(self.root, padx=20, pady=15, bg="#F8FAFC")
        self.main_container.pack(fill=tk.BOTH, expand=True)

        # Header
        self.header = tk.Frame(self.main_container, bg="#F8FAFC")
        self.header.pack(fill=tk.X, pady=(0, 20))

        self.title_lbl = tk.Label(self.header, text="📚 Student Task Tracker",
                                 font=("Segoe UI", 26, "bold"), bg="#F8FAFC", fg="#1E3A8A")
        self.title_lbl.pack(side=tk.LEFT)

        self.progress_frame = tk.LabelFrame(self.header, text=" Progress Overview ",
                                            font=("Segoe UI", 11, "bold"), padx=15, pady=10, bg="#F8FAFC")
        self.progress_frame.pack(side=tk.LEFT, padx=50)
        self.progress_label = tk.Label(self.progress_frame, text="0% Complete\n0 / 0 tasks",
                                       font=("Segoe UI", 13), bg="#F8FAFC", justify="center")
        self.progress_label.pack()

        # Dark Mode Toggle
        toggle_frame = tk.Frame(self.header, bg="#F8FAFC")
        toggle_frame.pack(side=tk.RIGHT, padx=10)
        self.dark_lbl = tk.Label(toggle_frame, text="Dark Mode", font=("Segoe UI", 10), bg="#F8FAFC")
        self.dark_lbl.pack(side=tk.LEFT)
        
        self.dark_var = tk.BooleanVar(value=False)
        self.dark_toggle = tk.Checkbutton(toggle_frame, text="🌙", variable=self.dark_var,
                                          command=self.toggle_dark_mode, font=("Segoe UI", 14),
                                          indicatoron=False, width=3, relief="solid", bd=1,
                                          bg="#F8FAFC", selectcolor="#6366F1")
        self.dark_toggle.pack(side=tk.LEFT, padx=8)

        add_btn = tk.Button(self.header, text="＋ Add New Task", font=("Segoe UI", 11, "bold"),
                            bg="#6366F1", fg="white", padx=20, pady=8, relief="flat",
                            command=self.add_task)
        add_btn.pack(side=tk.RIGHT)

        # Paned Window
        self.paned = tk.PanedWindow(self.main_container, orient=tk.HORIZONTAL, sashwidth=8, bg="#E2E8F0")
        self.paned.pack(fill=tk.BOTH, expand=True)

        # Sidebar
        self.sidebar = tk.LabelFrame(self.paned, text=" Subjects ", font=("Segoe UI", 12, "bold"),
                                     padx=15, pady=12, bg="#F8FAFC")
        self.paned.add(self.sidebar, minsize=240)

        self.subject_listbox = tk.Listbox(self.sidebar, height=20, font=("Segoe UI", 11),
                                          selectbackground="#6366F1", selectforeground="white", bd=0)
        self.subject_listbox.pack(fill=tk.BOTH, expand=True, pady=8)
        self.subject_listbox.bind("<<ListboxSelect>>", self.filter_by_subject)

        # Content Area
        self.content = tk.Frame(self.paned, bg="#F8FAFC")
        self.paned.add(self.content, minsize=800)

        toolbar = tk.Frame(self.content, bg="#F8FAFC")
        toolbar.pack(fill=tk.X, pady=(0, 12))

        tk.Button(toolbar, text="✏️ Multi-Edit", bg="#64748B", fg="white", padx=15, pady=6,
                  command=self.edit_task).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="🗑 Delete", bg="#EF4444", fg="white", padx=15, pady=6,
                  command=self.delete_task).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="✅ Toggle Done", bg="#10B981", fg="white", padx=15, pady=6,
                  command=self.toggle_complete).pack(side=tk.LEFT, padx=5)

        # Treeview (Updated for Multiselect)
        columns = ("id", "title", "subject", "priority", "due", "countdown", "status")
        self.task_tree = ttk.Treeview(self.content, columns=columns, show="headings", height=22, selectmode="extended")
        
        for col in columns:
            self.task_tree.heading(col, text=col.title())
            self.task_tree.column(col, anchor="center")
        
        self.task_tree.column("title", width=300, anchor="w")
        self.task_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        sb = ttk.Scrollbar(self.content, orient=tk.VERTICAL, command=self.task_tree.yview)
        self.task_tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        self.refresh_subject_list()

    # ====================== DARK MODE FIX ======================
    def toggle_dark_mode(self):
        self.dark_mode = self.dark_var.get()
        bg = "#1F2937" if self.dark_mode else "#F8FAFC"
        fg = "#F9FAFB" if self.dark_mode else "#1E293B"
        entry_bg = "#374151" if self.dark_mode else "white"

        self.root.configure(bg=bg)
        
        # Style configuration for ttk Treeview
        if self.dark_mode:
            self.style.theme_use('clam')
            self.style.configure("Treeview", background="#374151", foreground="white", fieldbackground="#374151", borderwidth=0)
            self.style.configure("Treeview.Heading", background="#4B5563", foreground="white", relief="flat")
            self.style.map("Treeview", background=[('selected', '#6366F1')])
        else:
            self.style.theme_use('default')
            self.style.configure("Treeview", background="white", foreground="black", fieldbackground="white")
            self.style.configure("Treeview.Heading", background="#E2E8F0", foreground="black")

        def repaint(widget):
            try:
                wtype = widget.winfo_class()
                if wtype in ("Frame", "LabelFrame", "PanedWindow"):
                    widget.configure(bg=bg)
                elif wtype == "Label":
                    # Exclude the main title if you want to keep its blue color
                    if widget != self.title_lbl:
                        widget.configure(bg=bg, fg=fg)
                    else:
                        widget.configure(bg=bg)
                elif wtype == "Listbox":
                    widget.configure(bg=entry_bg, fg=fg)
                elif wtype == "Checkbutton":
                    widget.configure(bg=bg, fg=fg, activebackground=bg, selectcolor="#6366F1")
            except: pass
            for child in widget.winfo_children():
                repaint(child)

        repaint(self.root)
        self.populate_task_list()

    # ====================== MULTI-EDIT LOGIC ======================
    def open_task_form(self, tasks_to_edit=None):
        """If tasks_to_edit is a list with >1 item, we enter Multi-Edit mode."""
        is_multi = tasks_to_edit and len(tasks_to_edit) > 1
        first_task = tasks_to_edit[0] if tasks_to_edit else None

        win = tk.Toplevel(self.root)
        win.title("Multi-Edit Tasks" if is_multi else ("Edit Task" if first_task else "Add Task"))
        win.geometry("500x550")
        win.configure(bg="#1F2937" if self.dark_mode else "white")
        win.grab_set()

        # Variables
        title_v = tk.StringVar(value=first_task["title"] if first_task and not is_multi else "")
        subj_v = tk.StringVar(value=first_task["subject"] if first_task else self.subjects[0])
        pri_v = tk.StringVar(value=first_task["priority"] if first_task else "Medium")
        due_v = tk.StringVar(value=first_task.get("due", "") if first_task and not is_multi else "")

        # UI helper
        def make_ui():
            bg_color = "#1F2937" if self.dark_mode else "white"
            text_color = "white" if self.dark_mode else "black"
            
            if not is_multi:
                tk.Label(win, text="Task Title", bg=bg_color, fg=text_color).pack(pady=(10,0))
                tk.Entry(win, textvariable=title_v, width=40).pack(pady=5)
            else:
                tk.Label(win, text="Editing Multiple Tasks", font=("Segoe UI", 12, "bold"), 
                         fg="#6366F1", bg=bg_color).pack(pady=10)
                tk.Label(win, text="Titles and Dates cannot be bulk-edited.", 
                         fg="gray", bg=bg_color).pack()

            tk.Label(win, text="Subject", bg=bg_color, fg=text_color).pack(pady=10)
            ttk.Combobox(win, textvariable=subj_v, values=self.subjects).pack()

            tk.Label(win, text="Priority", bg=bg_color, fg=text_color).pack(pady=10)
            ttk.Combobox(win, textvariable=pri_v, values=["High", "Medium", "Low"]).pack()

            if not is_multi:
                tk.Label(win, text="Due Date (DD/MM/YYYY HH:MM)", bg=bg_color, fg=text_color).pack(pady=10)
                tk.Entry(win, textvariable=due_v, width=40).pack()

        make_ui()

        def save_changes():
            if not is_multi:
                # Standard single task add/edit logic
                # [Validation logic from your original code goes here]
                new_task = {
                    "id": first_task["id"] if first_task else (max([t["id"] for t in self.tasks], default=0) + 1),
                    "title": title_v.get(), "subject": subj_v.get(),
                    "priority": pri_v.get(), "due": due_v.get(),
                    "done": first_task["done"] if first_task else False
                }
                if first_task:
                    idx = next(i for i, t in enumerate(self.tasks) if t["id"] == first_task["id"])
                    self.tasks[idx] = new_task
                else:
                    self.tasks.append(new_task)
            else:
                # Multi-edit logic: Only update Subject and Priority
                target_ids = [t["id"] for t in tasks_to_edit]
                for t in self.tasks:
                    if t["id"] in target_ids:
                        t["subject"] = subj_v.get()
                        t["priority"] = pri_v.get()
            
            self.save_data()
            self.populate_task_list()
            win.destroy()

        tk.Button(win, text="Save Changes", bg="#6366F1", fg="white", command=save_changes, padx=20).pack(pady=20)

    # ====================== WRAPPERS ======================
    def add_task(self):
        self.open_task_form()

    def edit_task(self):
        selected = self.task_tree.selection()
        if not selected:
            messagebox.showinfo("Select", "Select one or more tasks.")
            return
        
        tasks_to_edit = []
        for item in selected:
            task_id = int(self.task_tree.item(item, "values")[0])
            task = next(t for t in self.tasks if t["id"] == task_id)
            tasks_to_edit.append(task)
            
        self.open_task_form(tasks_to_edit)

    # [Remaining helper methods: delete_task, toggle_complete, validate_uk_date, etc. 
    # would follow your original logic but using list selection loops]

    def delete_task(self):
        selected = self.task_tree.selection()
        if not selected: return
        if messagebox.askyesno("Delete", f"Delete {len(selected)} tasks?"):
            ids_to_del = [int(self.task_tree.item(i, "values")[0]) for i in selected]
            self.tasks = [t for t in self.tasks if t["id"] not in ids_to_del]
            self.save_data()
            self.populate_task_list()

    def toggle_complete(self):
        selected = self.task_tree.selection()
        if not selected: return
        ids = [int(self.task_tree.item(i, "values")[0]) for i in selected]
        for t in self.tasks:
            if t["id"] in ids:
                t["done"] = not t.get("done", False)
        self.save_data()
        self.populate_task_list()

    def refresh_subject_list(self):
        self.subject_listbox.delete(0, tk.END)
        self.subject_listbox.insert(tk.END, "All Subjects")
        for s in sorted(self.subjects): self.subject_listbox.insert(tk.END, s)

    def populate_task_list(self, filtered=None):
        for item in self.task_tree.get_children(): self.task_tree.delete(item)
        tasks_to_show = filtered if filtered is not None else self.tasks
        for task in tasks_to_show:
            status = "✅ Done" if task.get("done", False) else "Pending"
            self.task_tree.insert("", tk.END, values=(task["id"], task["title"], task["subject"], task["priority"], task.get("due"), "", status))
        self.update_progress()

    def update_progress(self):
        total = len(self.tasks)
        done = sum(1 for t in self.tasks if t.get("done", False))
        percent = int((done / total) * 100) if total > 0 else 0
        self.progress_label.config(text=f"{percent}% Complete\n{done} / {total} tasks")

    def filter_by_subject(self, event=None):
        sel = self.subject_listbox.curselection()
        if not sel: return
        subject = self.subject_listbox.get(sel[0])
        if subject == "All Subjects": self.populate_task_list()
        else: self.populate_task_list([t for t in self.tasks if t["subject"] == subject])

    def refresh_countdowns(self):
        self.populate_task_list()
        self.root.after(60000, self.refresh_countdowns)

if __name__ == "__main__":
    app = StudentTaskTracker()
    app.root.mainloop()