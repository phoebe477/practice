# version 3.1 worked upon 
# working upon comments in read me
    # correcting dark mode 
    # implementing an error message when code detects a incorrect date might have been entered 

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime
import json
import os


class StudentTaskTracker:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Student Task Tracker")
        self.root.geometry("1320x780")
        self.root.minsize(1100, 680)

        # Data
        self.tasks = []
        self.subjects = ["General"]
        self.data_file = "student_tasks.json"
        self.dark_mode = False

        # Keep track of every widget for dark mode repainting
        self._all_widgets = []

        self.load_data()
        self.create_modern_gui()
        self.populate_task_list()

        # Auto-refresh countdown every 60 seconds
        self.root.after(60000, self.refresh_countdowns)

    # ====================== LOAD / SAVE ======================
    def load_data(self):
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.tasks = data.get("tasks", [])
                    self.subjects = data.get("subjects", ["General"])
            except:
                pass

    def save_data(self):
        try:
            with open(self.data_file, "w", encoding="utf-8") as f:
                json.dump({"tasks": self.tasks, "subjects": self.subjects}, f, indent=4)
        except Exception as e:
            messagebox.showerror("Save Error", f"Could not save data:\n{e}")

    # ====================== GUI ======================
    def create_modern_gui(self):
        # Main container
        main_frame = tk.Frame(self.root, padx=20, pady=15, bg="#F8FAFC")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # ==================== HEADER ====================
        header = tk.Frame(main_frame, bg="#F8FAFC")
        header.pack(fill=tk.X, pady=(0, 20))

        # Title
        tk.Label(header, text="📚 Student Task Tracker",
                 font=("Segoe UI", 26, "bold"), bg="#F8FAFC", fg="#1E3A8A").pack(side=tk.LEFT)

        # Progress Overview
        self.progress_frame = tk.LabelFrame(header, text=" Progress Overview ",
                                            font=("Segoe UI", 11, "bold"), padx=15, pady=10, bg="#F8FAFC")
        self.progress_frame.pack(side=tk.LEFT, padx=50)
        self.progress_label = tk.Label(self.progress_frame, text="0% Complete\n0 / 0 tasks",
                                       font=("Segoe UI", 13), bg="#F8FAFC", justify="center")
        self.progress_label.pack()

        # Search Bar
        search_frame = tk.Frame(header, bg="#F8FAFC")
        search_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=20)
        tk.Label(search_frame, text="🔍 Search tasks", font=("Segoe UI", 10), bg="#F8FAFC").pack(anchor="w")
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(search_frame, textvariable=self.search_var, font=("Segoe UI", 11),
                                     relief="solid", bd=1, highlightthickness=2, highlightcolor="#6366F1")
        self.search_entry.pack(fill=tk.X, pady=4)
        self.search_var.trace("w", lambda *args: self.filter_tasks())

        # Dark Mode Toggle
        toggle_frame = tk.Frame(header, bg="#F8FAFC")
        toggle_frame.pack(side=tk.RIGHT, padx=10)
        tk.Label(toggle_frame, text="Dark Mode", font=("Segoe UI", 10), bg="#F8FAFC").pack(side=tk.LEFT)
        self.dark_var = tk.BooleanVar(value=False)
        self.dark_toggle = tk.Checkbutton(toggle_frame, text="🌙", variable=self.dark_var,
                                          command=self.toggle_dark_mode, font=("Segoe UI", 14),
                                          indicatoron=False, width=3, relief="solid", bd=1,
                                          bg="#F8FAFC", selectcolor="#6366F1")
        self.dark_toggle.pack(side=tk.LEFT, padx=8)

        # Add Task Button
        add_btn = tk.Button(header, text="＋ Add New Task", font=("Segoe UI", 11, "bold"),
                            bg="#6366F1", fg="white", padx=20, pady=8, relief="flat",
                            command=self.add_task)
        add_btn.pack(side=tk.RIGHT)

        # ==================== MAIN LAYOUT ====================
        paned = tk.PanedWindow(main_frame, orient=tk.HORIZONTAL, sashwidth=8, bg="#E2E8F0")
        paned.pack(fill=tk.BOTH, expand=True)

        # Left Sidebar - Subjects
        sidebar = tk.LabelFrame(paned, text=" Subjects ", font=("Segoe UI", 12, "bold"),
                                padx=15, pady=12, bg="#F8FAFC")
        paned.add(sidebar, minsize=240)

        tk.Label(sidebar, text="Filter by subject:", font=("Segoe UI", 10, "bold"), bg="#F8FAFC").pack(anchor="w", pady=(0, 8))

        self.subject_listbox = tk.Listbox(sidebar, height=20, font=("Segoe UI", 11),
                                          selectbackground="#6366F1", selectforeground="white", bd=0)
        self.subject_listbox.pack(fill=tk.BOTH, expand=True, pady=8)
        self.subject_listbox.bind("<<ListboxSelect>>", self.filter_by_subject)

        btn_frame = tk.Frame(sidebar, bg="#F8FAFC")
        btn_frame.pack(fill=tk.X, pady=10)
        tk.Button(btn_frame, text="＋ Add Subject", bg="#E0E7FF", fg="#4338CA",
                  command=self.add_subject, relief="flat", padx=10).pack(side=tk.LEFT, padx=4)
        tk.Button(btn_frame, text="Show All", bg="#E0E7FF", fg="#4338CA",
                  command=self.show_all, relief="flat", padx=10).pack(side=tk.LEFT, padx=4)

        # Main Content Area
        content = tk.Frame(paned, bg="#F8FAFC")
        paned.add(content, minsize=800)

        # Toolbar
        toolbar = tk.Frame(content, bg="#F8FAFC")
        toolbar.pack(fill=tk.X, pady=(0, 12))

        tk.Button(toolbar, text="✏️ Edit", bg="#64748B", fg="white", padx=15, pady=6,
                  command=self.edit_task).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="🗑 Delete", bg="#EF4444", fg="white", padx=15, pady=6,
                  command=self.delete_task).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="✅ Toggle Done", bg="#10B981", fg="white", padx=15, pady=6,
                  command=self.toggle_complete).pack(side=tk.LEFT, padx=5)
        tk.Button(toolbar, text="🔄 Refresh", bg="#64748B", fg="white", padx=15, pady=6,
                  command=self.populate_task_list).pack(side=tk.RIGHT, padx=5)

        # Task List (Treeview)
        columns = ("id", "title", "subject", "priority", "due", "countdown", "status")
        self.task_tree = ttk.Treeview(content, columns=columns, show="headings", height=22)

        self.task_tree.heading("id", text="ID")
        self.task_tree.heading("title", text="Task Title")
        self.task_tree.heading("subject", text="Subject")
        self.task_tree.heading("priority", text="Priority")
        self.task_tree.heading("due", text="Due Date")
        self.task_tree.heading("countdown", text="⏳ Time Left")
        self.task_tree.heading("status", text="Status")

        self.task_tree.column("id", width=50, anchor="center")
        self.task_tree.column("title", width=340)
        self.task_tree.column("subject", width=140)
        self.task_tree.column("priority", width=100, anchor="center")
        self.task_tree.column("due", width=160, anchor="center")
        self.task_tree.column("countdown", width=160, anchor="center")
        self.task_tree.column("status", width=100, anchor="center")

        self.task_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Scrollbar
        scrollbar = ttk.Scrollbar(content, orient=tk.VERTICAL, command=self.task_tree.yview)
        self.task_tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.task_tree.bind("<Double-1>", lambda e: self.edit_task())

        # Color tags
        self.task_tree.tag_configure("High", background="#FEE2E2", foreground="#EF4444")
        self.task_tree.tag_configure("Medium", background="#FEF3C7", foreground="#F59E0B")
        self.task_tree.tag_configure("Low", background="#DCFCE7", foreground="#22C55E")
        self.task_tree.tag_configure("overdue", foreground="#B91C1C", font=("Segoe UI", 10, "bold"))
        self.task_tree.tag_configure("done", foreground="#6B7280", font=("Segoe UI", 10, "overstrike"))

        self.refresh_subject_list()

    # ====================== DARK MODE ======================
    def toggle_dark_mode(self):
        self.dark_mode = self.dark_var.get()
        bg       = "#1F2937" if self.dark_mode else "#F8FAFC"
        fg       = "#F9FAFB" if self.dark_mode else "#1E293B"
        entry_bg = "#374151" if self.dark_mode else "white"
        btn_bg   = "#374151" if self.dark_mode else "#E0E7FF"
        btn_fg   = "#F9FAFB" if self.dark_mode else "#4338CA"

        # Paint the root window itself
        self.root.configure(bg=bg)

        # Recursively repaint every tk widget in the whole window
        def repaint(widget):
            wtype = widget.winfo_class()
            try:
                if wtype in ("Frame", "LabelFrame", "PanedWindow"):
                    widget.configure(bg=bg)
                elif wtype == "Label":
                    # Keep coloured accent labels (title) readable
                    current_fg = widget.cget("fg")
                    if current_fg in ("#1E3A8A", "#1E293B", "black", "#F9FAFB",
                                      "SystemButtonText", ""):
                        widget.configure(bg=bg, fg=fg)
                    else:
                        widget.configure(bg=bg)
                elif wtype == "Entry":
                    widget.configure(bg=entry_bg, fg=fg, insertbackground=fg)
                elif wtype == "Listbox":
                    widget.configure(bg=entry_bg, fg=fg)
                elif wtype == "Checkbutton":
                    widget.configure(bg=bg, fg=fg,
                                     activebackground=bg, activeforeground=fg)
                elif wtype == "Button":
                    # Leave accent-coloured action buttons unchanged
                    current_bg = widget.cget("bg")
                    if current_bg in ("#6366F1", "#EF4444", "#10B981", "#64748B"):
                        pass  # keep the accent colour
                    else:
                        widget.configure(bg=btn_bg, fg=btn_fg,
                                         activebackground=btn_bg, activeforeground=btn_fg)
            except tk.TclError:
                pass  # widget doesn't support that option — skip silently

            for child in widget.winfo_children():
                repaint(child)

        repaint(self.root)
        self.populate_task_list()

    # ====================== PROGRESS ======================
    def update_progress(self):
        total = len(self.tasks)
        done = sum(1 for t in self.tasks if t.get("done", False))
        percent = int((done / total) * 100) if total > 0 else 0
        self.progress_label.config(text=f"{percent}% Complete\n{done} / {total} tasks")

    # ====================== COUNTDOWN ======================
    def get_countdown(self, due_str):
        if not due_str:
            return "No date"
        try:
            due = datetime.strptime(due_str, "%d/%m/%Y %H:%M")
            diff = due - datetime.now()
            if diff.total_seconds() <= 0:
                return "OVERDUE!"
            days = diff.days
            hours = diff.seconds // 3600
            mins = (diff.seconds % 3600) // 60
            return f"{days}d {hours}h" if days > 0 else f"{hours}h {mins}m"
        except:
            return "Invalid date"

    def populate_task_list(self, filtered=None):
        for item in self.task_tree.get_children():
            self.task_tree.delete(item)

        tasks_to_show = filtered if filtered is not None else self.tasks

        def sort_key(t):
            try:
                return datetime.strptime(t.get("due", ""), "%d/%m/%Y %H:%M")
            except:
                return datetime.max

        for task in sorted(tasks_to_show, key=sort_key):
            countdown = self.get_countdown(task.get("due"))
            status = "✅ Done" if task.get("done", False) else "Pending"

            item = self.task_tree.insert("", tk.END, values=(
                task["id"], task["title"], task["subject"], task["priority"],
                task.get("due", "—"), countdown, status
            ))

            if task.get("done", False):
                self.task_tree.item(item, tags=("done",))
            elif countdown == "OVERDUE!":
                self.task_tree.item(item, tags=("overdue",))
            else:
                pri = task.get("priority")
                if pri in ("High", "Medium", "Low"):
                    self.task_tree.item(item, tags=(pri,))

        self.update_progress()

    def refresh_countdowns(self):
        self.populate_task_list()
        self.root.after(60000, self.refresh_countdowns)

    # ====================== DATE VALIDATION ======================
    def validate_uk_date(self, due_str):
        """
        Validates that due_str is in DD/MM/YYYY HH:MM format and is a future date.
        Returns (True, datetime_obj) on success, or (False, error_message) on failure.
        """
        due_str = due_str.strip()

        if not due_str:
            return True, None  # blank is allowed (no due date)

        # ── Check overall structure ──────────────────────────────────────────
        if " " not in due_str:
            return False, (
                "Missing time.\n\n"
                "Expected format:  DD/MM/YYYY HH:MM\n"
                "Example:          23/04/2026 14:30\n\n"
                "Hint: add a space then the time after the date."
            )

        date_part, time_part = due_str.split(" ", 1)

        # ── Validate date part ───────────────────────────────────────────────
        if date_part.count("/") != 2:
            return False, (
                f"Date '{date_part}' is not in the right format.\n\n"
                "Expected:  DD/MM/YYYY  (with slashes)\n"
                "Example:   23/04/2026\n\n"
                "Hint: use slashes ( / ) to separate day, month and year."
            )

        day_s, month_s, year_s = date_part.split("/")

        if not (day_s.isdigit() and month_s.isdigit() and year_s.isdigit()):
            return False, (
                "Date contains non-numeric characters.\n\n"
                "Expected:  DD/MM/YYYY\n"
                "Example:   23/04/2026\n\n"
                "Hint: day, month and year must all be numbers."
            )

        if len(year_s) != 4:
            return False, (
                f"Year '{year_s}' should be 4 digits.\n\n"
                "Expected:  DD/MM/YYYY\n"
                "Example:   23/04/2026\n\n"
                "Hint: write the full 4-digit year (e.g. 2026, not 26)."
            )

        # ── Validate time part ───────────────────────────────────────────────
        if ":" not in time_part:
            return False, (
                f"Time '{time_part}' is not in the right format.\n\n"
                "Expected:  HH:MM  (24-hour clock)\n"
                "Example:   14:30\n\n"
                "Hint: separate hours and minutes with a colon ( : )."
            )

        hour_s, min_s = time_part.split(":", 1)

        if not (hour_s.isdigit() and min_s.isdigit()):
            return False, (
                "Time contains non-numeric characters.\n\n"
                "Expected:  HH:MM\n"
                "Example:   14:30\n\n"
                "Hint: hours and minutes must be numbers (24-hour clock)."
            )

        # ── Parse and range-check ────────────────────────────────────────────
        try:
            due_dt = datetime.strptime(due_str, "%d/%m/%Y %H:%M")
        except ValueError as e:
            err = str(e)
            if "day" in err:
                hint = f"Hint: day '{day_s}' is out of range for month {month_s}."
            elif "month" in err:
                hint = f"Hint: month '{month_s}' must be between 01 and 12."
            elif "hour" in err:
                hint = f"Hint: hour '{hour_s}' must be between 00 and 23."
            elif "minute" in err:
                hint = f"Hint: minute '{min_s}' must be between 00 and 59."
            else:
                hint = f"Hint: {err}"

            return False, (
                f"'{due_str}' is not a valid date/time.\n\n"
                "Expected format:  DD/MM/YYYY HH:MM\n"
                "Example:          23/04/2026 14:30\n\n"
                + hint
            )

        # ── Must be a future date ────────────────────────────────────────────
        if due_dt <= datetime.now():
            return False, (
                f"'{due_str}' is in the past.\n\n"
                "Due dates must be in the future.\n\n"
                f"Hint: today is {datetime.now().strftime('%d/%m/%Y')} — "
                "please choose a later date or time."
            )

        return True, due_dt

    # ====================== SEARCH ======================
    def filter_tasks(self):
        query = self.search_var.get().lower().strip()
        if not query:
            self.populate_task_list()
            return
        filtered = [t for t in self.tasks if query in t["title"].lower()]
        self.populate_task_list(filtered)

    # ====================== SUBJECTS ======================
    def refresh_subject_list(self):
        self.subject_listbox.delete(0, tk.END)
        self.subject_listbox.insert(tk.END, "All Subjects")
        for s in sorted(self.subjects):
            self.subject_listbox.insert(tk.END, s)

    def add_subject(self):
        name = simpledialog.askstring("New Subject", "Enter subject name:", parent=self.root)
        if name and name.strip() and name.strip() not in self.subjects:
            self.subjects.append(name.strip())
            self.refresh_subject_list()
            self.save_data()

    def filter_by_subject(self, event=None):
        sel = self.subject_listbox.curselection()
        if not sel:
            return
        subject = self.subject_listbox.get(sel[0])
        if subject == "All Subjects":
            self.populate_task_list()
        else:
            filtered = [t for t in self.tasks if t["subject"] == subject]
            self.populate_task_list(filtered)

    def show_all(self):
        self.subject_listbox.selection_clear(0, tk.END)
        self.populate_task_list()

    # ====================== TASK FORM ======================
    def open_task_form(self, task=None):
        win = tk.Toplevel(self.root)
        win.title("Add New Task" if not task else "Edit Task")
        win.geometry("520x520")
        win.grab_set()

        # Apply current dark/light theme to the popup
        bg       = "#1F2937" if self.dark_mode else "white"
        fg       = "#F9FAFB" if self.dark_mode else "#1E293B"
        entry_bg = "#374151" if self.dark_mode else "white"
        win.configure(bg=bg)

        def lbl(text):
            tk.Label(win, text=text, font=("Segoe UI", 11, "bold"),
                     bg=bg, fg=fg).pack(anchor="w", padx=30, pady=(15, 3))

        def ent(var):
            e = tk.Entry(win, textvariable=var, font=("Segoe UI", 11),
                         bg=entry_bg, fg=fg, insertbackground=fg,
                         relief="solid", bd=1, width=50)
            e.pack(fill=tk.X, padx=30, pady=3)
            return e

        title_var    = tk.StringVar(value=task["title"] if task else "")
        subject_var  = tk.StringVar(value=task["subject"] if task else self.subjects[0])
        priority_var = tk.StringVar(value=task["priority"] if task else "Medium")
        due_var      = tk.StringVar(value=task.get("due", "") if task else "")

        lbl("Task Title *")
        ent(title_var)

        lbl("Subject")
        ttk.Combobox(win, textvariable=subject_var, values=self.subjects,
                     state="readonly").pack(fill=tk.X, padx=30, pady=3)

        lbl("Priority")
        ttk.Combobox(win, textvariable=priority_var, values=["High", "Medium", "Low"],
                     state="readonly").pack(fill=tk.X, padx=30, pady=3)

        lbl("Due Date & Time  (DD/MM/YYYY HH:MM)")
        due_entry = ent(due_var)

        # Inline error label — hidden until needed
        error_lbl = tk.Label(win, text="", fg="#EF4444", bg=bg,
                             font=("Segoe UI", 9), wraplength=440, justify="left")
        error_lbl.pack(anchor="w", padx=30)

        tk.Label(win, text="Example:  23/04/2026 15:30  (24-hour clock)",
                 fg="gray", bg=bg).pack(anchor="w", padx=30)

        def save():
            error_lbl.config(text="")

            if not title_var.get().strip():
                messagebox.showwarning("Required", "Task title is required!", parent=win)
                return

            ok, result = self.validate_uk_date(due_var.get())
            if not ok:
                # Show the hint directly below the field instead of a pop-up
                error_lbl.config(text="⚠  " + result)
                due_entry.focus_set()
                return

            new_task = {
                "id":       task["id"] if task else len(self.tasks) + 1,
                "title":    title_var.get().strip(),
                "subject":  subject_var.get(),
                "priority": priority_var.get(),
                "due":      due_var.get().strip(),
                "done":     task.get("done", False) if task else False,
            }

            if task:
                for i, t in enumerate(self.tasks):
                    if t["id"] == task["id"]:
                        self.tasks[i] = new_task
                        break
            else:
                self.tasks.append(new_task)

            self.save_data()
            self.populate_task_list()
            win.destroy()

        tk.Button(win, text="💾 Save Task", font=("Segoe UI", 11, "bold"),
                  bg="#6366F1", fg="white", padx=30, pady=10,
                  command=save).pack(pady=20)

    def add_task(self):
        self.open_task_form()

    def edit_task(self):
        selected = self.task_tree.selection()
        if not selected:
            messagebox.showinfo("Select", "Please select a task to edit.")
            return
        values = self.task_tree.item(selected[0], "values")
        task = next((t for t in self.tasks if t["id"] == int(values[0])), None)
        if task:
            self.open_task_form(task)

    def delete_task(self):
        selected = self.task_tree.selection()
        if not selected:
            messagebox.showinfo("Select", "Please select a task.")
            return
        if messagebox.askyesno("Delete", "Delete this task permanently?"):
            task_id = int(self.task_tree.item(selected[0], "values")[0])
            self.tasks = [t for t in self.tasks if t["id"] != task_id]
            self.save_data()
            self.populate_task_list()

    def toggle_complete(self):
        selected = self.task_tree.selection()
        if not selected:
            messagebox.showinfo("Select", "Please select a task.")
            return
        task_id = int(self.task_tree.item(selected[0], "values")[0])
        for task in self.tasks:
            if task["id"] == task_id:
                task["done"] = not task.get("done", False)
                break
        self.save_data()
        self.populate_task_list()


# ====================== RUN THE APP ======================
if __name__ == "__main__":
    app = StudentTaskTracker()
    app.root.mainloop()