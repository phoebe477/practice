import tkinter as tk
from tkinter import ttk, messagebox

class TaskView(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Smart-Task Academic Manager")
        self.geometry("600x500")

        # Dashboard Summary [cite: 15]
        self.stats_label = tk.Label(self, text="Total Tasks: 0 | Completed: 0", font=('Arial', 10, 'bold'))
        self.stats_label.pack(pady=10)

        # Task List (Treeview) [cite: 11, 12]
        self.tree = ttk.Treeview(self, columns=("ID", "Title", "Deadline", "Priority", "Status"), show='headings')
        for col in ("ID", "Title", "Deadline", "Priority", "Status"):
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        self.tree.pack(pady=10, fill=tk.X)

        # Input Fields [cite: 28]
        self.entry_title = tk.Entry(self)
        self.entry_title.pack(placeholder="Task Title") # Note: Custom placeholder logic needed
        
        # Buttons
        self.add_btn = tk.Button(self, text="Add Task")
        self.add_btn.pack(side=tk.LEFT, padx=10)
        
        self.del_btn = tk.Button(self, text="Delete Selected", fg="red")
        self.del_btn.pack(side=tk.LEFT, padx=10)

    def show_error(self, message):
        """Displays error messages to the user[cite: 28]."""
        messagebox.showerror("Error", message)