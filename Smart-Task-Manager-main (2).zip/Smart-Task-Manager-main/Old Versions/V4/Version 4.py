from Version4Model import TaskModel
from Version4View import TaskView
import tkinter as tk

class TaskController:
    def __init__(self, model, view):
        self.model = model
        self.view = view
        
        # Bind buttons to methods
        self.view.add_btn.config(command=self.handle_add_task)
        self.view.del_btn.config(command=self.handle_delete_task)
        
        self.refresh_view()

    def handle_add_task(self):
        title = self.view.entry_title.get()
        # Basic validation [cite: 28]
        if not title:
            self.view.show_error("Task title cannot be empty!")
            return
            
        self.model.add_task(title, "2024-05-01", "High")
        self.refresh_view()

    def handle_delete_task(self):
        selected_item = self.view.tree.selection()
        if selected_item:
            # Logic to find index and delete [cite: 11]
            index = self.view.tree.index(selected_item)
            self.model.delete_task(index)
            self.refresh_view()

    def refresh_view(self):
        """Updates the UI with current data[cite: 15]."""
        for item in self.view.tree.get_children():
            self.view.tree.delete(item)
        for task in self.model.tasks:
            self.view.tree.insert("",tk.END, values=(task['id'], task['title'], task['deadline'], task['priority'], task['status']))

if __name__ == "__main__":
    app_model = TaskModel()
    app_view = TaskView()
    app_controller = TaskController(app_model, app_view)
    app_view.mainloop()