import json
import os

class TaskModel:
    def __init__(self, filename='tasks.json'):
        self.filename = filename
        self.tasks = self.load_tasks()

    def load_tasks(self):
        """Loads tasks from a JSON file[cite: 13, 39]."""
        if os.path.exists(self.filename):
            with open(self.filename, 'r') as f:
                return json.load(f)
        return []

    def save_tasks(self):
        """Persists data to the JSON file[cite: 13, 39]."""
        with open(self.filename, 'w') as f:
            json.dump(self.tasks, f, indent=4)

    def add_task(self, title, deadline, priority):
        """Creates a new task[cite: 11]."""
        task = {
            "id": len(self.tasks) + 1,
            "title": title,
            "deadline": deadline,
            "priority": priority,
            "status": "Pending"
        }
        self.tasks.append(task)
        self.save_tasks()

    def delete_task(self, task_index):
        """Deletes a task[cite: 11]."""
        if 0 <= task_index < len(self.tasks):
            del self.tasks[task_index]
            self.save_tasks()